"""A library to compute equilibria of 2 player normal form games"""
from .game import Game

__version__ = "0.0.28"
