Discussion
==========

.. toctree::
   :maxdepth: 2

   normal-form-games.rst
   strategies.rst
   best-responses.rst
   support-enumeration.rst
   vertex-enumeration.rst
   extensive-form-games.rst
   lemke-howson.rst
   degenerate-games.rst
   fictitious-play.rst
   stochastic-fictitious-play.rst
   replicator-dynamics.rst
   asymmetric-replicator-dynamics.rst
