.. _interrogate-discussion:

Checking the presence of docstrings with interrogate
====================================================

TODO
