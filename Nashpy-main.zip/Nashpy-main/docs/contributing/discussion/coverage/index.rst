.. _coverage-discussion:

Checking code is tested with coverage
=====================================

TODO
