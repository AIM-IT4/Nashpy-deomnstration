Static code analysis with flake8
================================

TODO
