Using Github Actions to check automatically run all checks and publish new releases
===================================================================================

TODO
