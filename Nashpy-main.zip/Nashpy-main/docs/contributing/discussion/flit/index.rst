.. _flit-discussion:

Installing and packaging with flit
==================================

TODO
