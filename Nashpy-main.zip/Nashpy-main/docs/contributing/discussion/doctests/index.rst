Ensuring the code in the documentation is correct with doctests
===============================================================

TODO
