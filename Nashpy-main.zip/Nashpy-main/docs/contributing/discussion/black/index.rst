.. _black-discussion:

.. <!--alex ignore black-->

Ensuring consistent code style with Black
=========================================

TODO
