.. _how-to-fork:

How to fork the repository
==========================

1. Navigate to https://github.com/drvinceknight/Nashpy
2. Click on `Fork`
3. Follow any remaining instructions, for example if you have an organisation
   account on Github you will be prompted to say which account you would like to
   fork with.
