.. _how-to-push-changes:

How to push changes
===================

In order to push a copy of your committed changes on the :code:`<branch-name>`
branch to
:ref:`your fork of the repository on github <how-to-fork>`
run the following at your command line::

    $ git push origin <branch-name>
