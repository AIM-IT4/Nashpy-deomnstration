How to install the library from source
======================================

To install the library from the source files::

    $ python -m pip install flit
    $ python -m flit install

How to install an editable version of the library from source
-------------------------------------------------------------

If you want to install a version of the library from the source files so that
modifications of the source files are directly usable::

    $ python -m flit install --symlink
