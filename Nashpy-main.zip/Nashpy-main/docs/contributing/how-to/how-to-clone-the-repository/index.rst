How to clone the repository
===========================

In order to obtain a copy of
:ref:`your fork of the repository on github <how-to-fork>` to your local machine
run the following at your command line::

    $ git clone https://github.com/<username>/Nashpy.git
