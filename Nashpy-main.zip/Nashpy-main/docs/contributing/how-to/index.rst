How to
======

How to:

.. toctree::
   :maxdepth: 1

   how-to-fork-the-repository/index.rst
   how-to-clone-the-repository/index.rst
   how-to-update-from-upstream/index.rst
   how-to-create-a-branch/index.rst
   how-to-create-a-virtualenv/index.rst
   how-to-install-the-library-from-source/index.rst
   how-to-run-tests/index.rst
   how-to-check-for-insensitive-language/index.rst
   how-to-write-a-docstring/index.rst
   how-to-write-a-typehint/index.rst
   how-to-write-tests/index.rst
   how-to-make-a-commit/index.rst
   how-to-push-changes/index.rst
   how-to-open-a-pull-request/index.rst
