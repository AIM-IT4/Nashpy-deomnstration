.. _contributing-bibliography:

Contributing Bibliography
=========================

This is a collection of various bibliographic items referenced in the
contributor documentation.

.. [Procida2021] Daniele Procida. Diátaxis: A Systematic Framework For Technical Documentation Authoring. https://diataxis.fr
.. [Knight2018] Knight and Campbell, (2018). Nashpy: A Python library for the computation of Nash equilibria. Journal of Open Source Software, 3(30), 904, https://doi.org/10.21105/joss.00904
