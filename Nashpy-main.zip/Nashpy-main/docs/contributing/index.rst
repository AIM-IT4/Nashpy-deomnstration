.. Nashpy documentation main file, created by
   sphinx-quickstart on Sat Jun 17 12:30:44 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Contributor documentation
=========================

This is guide explains the various tools and steps used to contribute code to
Nashpy.

.. toctree::
   :maxdepth: 2

   tutorial/index.rst
   how-to/index.rst
   discussion/index.rst
   reference/index.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
