Install Nashpy
==============

:code:`Nashpy` currently requires Python 3.5 or above. To install from the
Python Package index (PyPi) run the following command::

    $ python -m pip install nashpy

To install a development version from source::

    $ git clone https://github.com/drvinceknight/Nashpy.git
    $ cd nashpy
    $ python -m pip install flit
    $ python -m flit install --symlink
