Reference
=========

.. toctree::
   :maxdepth: 1

   john-nash.rst
   gambit.rst
   other-python-game-theory-libraries.rst
   bibliography.rst
   source/nashpy.rst
