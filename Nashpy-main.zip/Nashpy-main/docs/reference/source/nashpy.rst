Source files
============

Subpackages
-----------

.. toctree::

    nashpy.algorithms
    nashpy.learning

Submodules
----------

nashpy\.game module
-------------------

.. automodule:: nashpy.game
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: nashpy
    :members:
    :undoc-members:
    :show-inheritance:
