nash\.learning package
======================

Submodules
----------

nashpy\.learning\.\fictitious\_play module
------------------------------------------

.. automodule:: nashpy.learning.fictitious_play
    :members:
    :undoc-members:
    :show-inheritance:
