Source files for an image used in the description of extensive form games.

Compilation instructions:

    $ latexmk --xelatex main.tex
    $ convert -density 300 main.pdf -quality 90 main.png
