Two demo files for the alex discussion section in the documentation.
