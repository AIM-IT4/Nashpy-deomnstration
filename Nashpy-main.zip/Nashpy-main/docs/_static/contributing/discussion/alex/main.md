# A typical user of Nashpy

He will use it to study games.
