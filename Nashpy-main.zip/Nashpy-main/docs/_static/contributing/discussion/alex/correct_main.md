# A typical user of Nashpy

They will use it to study games.
