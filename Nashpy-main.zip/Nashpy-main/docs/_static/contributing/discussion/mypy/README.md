3 demo files for the mypy discussion section in the documentation.
