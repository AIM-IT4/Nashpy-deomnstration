A demo file for the darglint discussion section in the documentation.
